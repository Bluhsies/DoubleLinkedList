var searchData=
[
  ['setnext_0',['setNext',['../class_double_linked_list_node.html#ac586e5125dcdb9019f8d36e1c3e584d5',1,'DoubleLinkedListNode']]],
  ['setprevious_1',['setPrevious',['../class_double_linked_list_node.html#a9cc4441102dc618b201960045bf5078d',1,'DoubleLinkedListNode']]]
];
