var searchData=
[
  ['empty_0',['empty',['../class_double_linked_list.html#ad7459f36a02d10cc652533f4c0302c35',1,'DoubleLinkedList']]]
];
